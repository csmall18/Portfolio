#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include "cipher.h"
// cctype is for the tolower() function

// Try to add a read file functionality - 10/19/2019 - Completed - 10/22/2019
// No bugs found as of 10/22/2019

using namespace std;

// GLOBAL VARIABLES
cipher enc; // create class object to access public member functions
//string temp; // string to pass user input to
int shft; // shift variable
string output_string; // assign encoded message to
string filename;
int num_lines = 0;
int * num_words_ptr;
int numWords;

string lower_case(string txt) { // change word into lowercase
    transform(txt.begin(), txt.end(), txt.begin(),
    [](unsigned char c){ return tolower(c); });
    return txt;
}

void valid_shift() {
    cout << "Please enter the number that you'd like to shift by." << endl;
    cin >> shft; // pass to shft
    while (!cin) {
        cout << "Your input is not an integer." << endl; // keep looping until input is integer
        cin.clear();
        cin.ignore();
        cin >> shft;
    }
    if (cin) {
        enc.set_shift_value(shft); // pass value to shift member
        //cout << "Shift Value: " << enc.get_shift_value() << endl;
    }
}

void print_file_text(string fname) {
    filename = fname;
    string line;
    fstream file;
    file.open(fname.c_str());
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
}

void display_encryption() {
    string line;
    fstream file;
    file.open(filename.c_str());
    string c_line;
    while (getline(file, line)) {
        line = lower_case(line); // lower case the line so characters are searchable in alphabet
        enc.set_curr_line(line); // set curr line in private data member
        c_line = enc.encrypt_file_txt(line);
        cout << c_line << endl; // print encoded line
    }
    file.close();
    cout << "\nEncryption Complete.";
}

int main() {
    cout << "Welcome to the Caesar Cipher Text Encoder!" << endl;
    cout << "Please enter the name of the file you are trying to read." << endl;
    cin >> filename;

    valid_shift(); // Makes sure input is an integer

    cout << "Original Message: " << endl;
    print_file_text(filename);

    cout << "\nEncrypted Message: " << endl;
    display_encryption();
    return 0;
}