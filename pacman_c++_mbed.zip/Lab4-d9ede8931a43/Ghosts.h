#pragma once

#include "Sprite.h"

class Ghosts : public Sprite
{
    public:
        virtual void Move();
        virtual bool IsMoveAllowed(const int &nNewRow, const int &nNewCol,enDIRECTIONS drct){return true;}
        //void DrawGhosts(const int&,const int&);    
};

