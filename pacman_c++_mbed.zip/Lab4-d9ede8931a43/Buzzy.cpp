#include "Buzzy.h"
#include "Ghosts.h"
#include "BuzzyGraphics.h"
#include "uLCD_4DGL.h"
#include "Speaker.h"

// for debugging
DigitalOut l1(LED1);
DigitalOut l2(LED2);
DigitalOut l3(LED3);
DigitalOut l4(LED4);

extern char gDynaMaze[MAZE_NUM_ROW][MAZE_NUM_COL]; 
extern Ghosts gGhosts[NUM_GHOSTS];
extern Buzzy gBuzzy;
extern uLCD_4DGL guLCD;
extern Speaker gSpeakerOut;

extern int sRow = 25; // 40 rows total
extern int sCol = 21; // 42 columns total
int cRow;
int cCol;
int xs = (3*sRow+1)-4;
int ys = (3*sCol+1)-4;
int xmax = (3*39+1)-4;
int ymax = (3*42+1)-4;
int numDrops = 0;
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// Constructor
Buzzy::Buzzy(enDIRECTIONS inDir, unsigned int inRow, unsigned int inCol):
    Sprite(inDir, inRow, inCol)
{

}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void Buzzy::Move()
{
if (m_DesiredDirection != m_CurrentDirection) {

    if (m_DesiredDirection == NO_DIR) {
        // Nothing to do
        // Switch over to the siren sound
        gSpeakerOut.SwitchSound(Speaker::SIREN);
        return;
    }
    // Try to move buzzy in the desired direction

    // If failed to move in desired direction then try to move Buzzy in old direction
    else if (m_DesiredDirection == LEFT_DIR && (Buzzy::IsMoveAllowed(sRow,sCol,m_DesiredDirection) == true)) {
            l1 = 1;
            cCol = sCol;
            gBuzzy.DrawInNewLocation(sRow,--sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0;
            } else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gDynaMaze[sRow][sCol] = 0;
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
            }
                int xm = 3*sRow+1;
                int ym = 3*(++cCol)+1;
                guLCD.filled_rectangle(xm-3, ym-2, xm+4, ym+1, BLACK);
        l1 = 0;
        return;

    }

    else if (m_DesiredDirection == RIGHT_DIR && (Buzzy::IsMoveAllowed(sRow,sCol,m_DesiredDirection) == true)) {
            l2 = 1;
            cCol = sCol;
            gBuzzy.DrawInNewLocation(sRow,++sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            
            int xm = 3*sRow+1;
            int ym = 3*(--cCol)+1;
            guLCD.filled_rectangle(xm-4, ym-1, xm+4, ym+1, BLACK);
        l2 = 0;
        return;
    }

    else if (m_DesiredDirection == UP_DIR && (Buzzy::IsMoveAllowed(sRow,sCol,m_DesiredDirection) == true)) {
            l3 = 1;
            cRow = sRow;
            gBuzzy.DrawInNewLocation(++sRow,sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            int xm = 3*(--cRow)+1;
            int ym = 3*(sCol)+1;
            guLCD.filled_rectangle(xm-1, ym-3, xm+1, ym+3, BLACK);
        l3 = 0;
        return;

    }

else if (m_DesiredDirection == DOWN_DIR && (Buzzy::IsMoveAllowed(sRow,sCol,m_DesiredDirection) == true)) {
            l4 = 1;
            cRow = sRow;
            gBuzzy.DrawInNewLocation(--sRow,sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            int xm = 3*(++cRow)+1;
            int ym = 3*(sCol)+1;
            guLCD.filled_rectangle(xm-1, ym-3, xm+1, ym+3, BLACK);
        l4 = 0;
        return;
}

} // end of if 

switch (m_CurrentDirection) {
    case NO_DIR:
        break;
    case LEFT_DIR:
        if (IsMoveAllowed(sRow,sCol,m_CurrentDirection) == true) {
            l1 = 1;
            cCol = sCol;
            gBuzzy.DrawInNewLocation(sRow,--sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0;
            } else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gDynaMaze[sRow][sCol] = 0;
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
            }
                int xm = 3*sRow+1;
                int ym = 3*(++cCol)+1;
                guLCD.filled_rectangle(xm-3, ym-2, xm+4, ym+1, BLACK);
            l1 = 0;
        }   
        break;
    case RIGHT_DIR:
        if (IsMoveAllowed(sRow,sCol,m_CurrentDirection) == true) {
            l2 = 1;
            cCol = sCol;
            gBuzzy.DrawInNewLocation(sRow,++sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            
            int xm = 3*sRow+1;
            int ym = 3*(--cCol)+1;
            guLCD.filled_rectangle(xm-4, ym-1, xm+4, ym+1, BLACK);
            l2 = 0;       
        }
        break;
    case UP_DIR:
        if (IsMoveAllowed(sRow,sCol,m_CurrentDirection) == true) {
            l3 = 1;
            cRow = sRow;
            gBuzzy.DrawInNewLocation(++sRow,sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            int xm = 3*(--cRow)+1;
            int ym = 3*(sCol)+1;
            guLCD.filled_rectangle(xm-1, ym-3, xm+1, ym+3, BLACK);
            l3 = 0;    
        }
        break;
    case DOWN_DIR:
        if (IsMoveAllowed(sRow,sCol,m_CurrentDirection) == true) {
            l4 = 1;
            cRow = sRow;
            gBuzzy.DrawInNewLocation(--sRow,sCol);
            gSpeakerOut.SwitchSound(Speaker::CHOMP);
            if (gDynaMaze[sRow][sCol] == HONEYDROP_SQUARE) {
                ++numDrops;
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            else if (gDynaMaze[sRow][sCol] == PWRUP_SQUARE) {
                gSpeakerOut.SwitchSound(Speaker::EAT_FRUIT);
                gDynaMaze[sRow][sCol] = 0; // update gDynaMaze
            }
            int xm = 3*(++cRow)+1;
            int ym = 3*(sCol)+1;
            guLCD.filled_rectangle(xm-1, ym-3, xm+1, ym+3, BLACK);
            l4 = 0;
        }
        break;     
}
       
}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void Buzzy::DrawInNewLocation(const int &nRow,const int &nCol)
{
    int x1, y1;
    // Test if we hit a honeydrop or fruit or ghost
    // Clean up the part that will be left

    gBuzzy.SetLocation(nRow, nCol); 
    x1 = (3*m_RowPos+1)-4;
    y1 = (3*m_ColPos+1)-4;
    
    if (m_DesiredDirection == LEFT_DIR) {
        if (gDynaMaze[sRow][sCol-3] == PWRUP_SQUARE) {
            guLCD.filled_rectangle(x1, y1-6, x1+7, y1+2, BLACK);
        }
    }
    
    else if (m_DesiredDirection == RIGHT_DIR) {
        if (gDynaMaze[sRow][sCol+3] == PWRUP_SQUARE) {
            guLCD.filled_rectangle(x1, y1+6, x1+7, y1+16, BLACK);
        }
    }
    
    else if (m_DesiredDirection == UP_DIR) {
        if (gDynaMaze[sRow+3][sCol] == PWRUP_SQUARE || gDynaMaze[sRow+2][sCol] == PWRUP_SQUARE) {
            guLCD.filled_rectangle(x1+6, y1, x1+16, y1+7, BLACK);
        }
    }
    else if (m_DesiredDirection == DOWN_DIR) {
        if (gDynaMaze[sRow+3][sCol] == PWRUP_SQUARE || gDynaMaze[sRow+2][sCol] == PWRUP_SQUARE) {
            guLCD.filled_rectangle(x1-6, y1, x1+2, y1+7, BLACK);
        }
    }                
    guLCD.BLIT(x1, y1, 9, 9, &BuzzyIcon[GetImageIndex()][0][0]);      
}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool Buzzy::DidGhostGetBuzzy()
{

    return false;
}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
bool Buzzy::IsMoveAllowed(const int &nNewRow, const int &nNewCol, enDIRECTIONS direct)
{
    if (direct == LEFT_DIR && (gDynaMaze[nNewRow][nNewCol-2] != BLUE_SQUARE) && (gDynaMaze[nNewRow-1][nNewCol-2] != BLUE_SQUARE) && (gDynaMaze[nNewRow+1][nNewCol-2] != BLUE_SQUARE))
    {
        m_CurrentDirection = direct;
        return true;    
    }
    
    else if (direct == RIGHT_DIR && (gDynaMaze[nNewRow][nNewCol+2] != BLUE_SQUARE) && (gDynaMaze[nNewRow+1][nNewCol+2] != BLUE_SQUARE) && (gDynaMaze[nNewRow-1][nNewCol+2] != BLUE_SQUARE))
    {
        m_CurrentDirection = direct;
        return true;    
    }

    else if (direct == UP_DIR && (gDynaMaze[nNewRow+2][nNewCol] != BLUE_SQUARE) && (gDynaMaze[nNewRow+2][nNewCol+1] != BLUE_SQUARE) && (gDynaMaze[nNewRow+2][nNewCol-1] != BLUE_SQUARE))
    {
        m_CurrentDirection = direct;
        return true; 
    }
    
    else if (direct == DOWN_DIR && (gDynaMaze[nNewRow-2][nNewCol] != BLUE_SQUARE) && (gDynaMaze[nNewRow-2][nNewCol+1] != BLUE_SQUARE) && (gDynaMaze[nNewRow-2][nNewCol-1] != BLUE_SQUARE))
    {
        m_CurrentDirection = direct;
        return true; 
    }
    
    else {
        gSpeakerOut.SwitchSound(Speaker::SIREN);
        return false;
    }
    
    
}
