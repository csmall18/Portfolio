#include "uLCD_4DGL.h"
#include "BuzzyGraphics.h"
#include "Buzzy.h"
#include "Sprite.h"
#include "mbed.h"
#include "Ghosts.h"

#define BLUE_SQUARE 1
#define HONEYDROP_SQUARE 2
#define PWRUP_SQUARE 3
#define GHOST_ICON 4
#define BUZZY_ICON 5
#define TRAP_LINE 6

extern uLCD_4DGL guLCD;
extern char gDynaMaze[MAZE_NUM_ROW][MAZE_NUM_COL]; 
extern Buzzy gBuzzy;
int kk = 0;
int nd = 0;

/////////////////////////////////////////////////////////////////////
// The maze is a scaled down version of the LCD display
// Each element in the maze is really a 3x3 segment of the LCD
// This must be taken into account when drawing the maze on the LCD


// Draw a wall tile when 
void DrawMazeWall(int const &x1, int const &y1)
{
    int ii = 3*x1+1;
    int jj = 3*y1+1;
    guLCD.filled_rectangle(ii-1, jj-1, ii+1, jj+1, _BLUE);
}
/*
//////////////////////////////////////////////////////////////////////
Use the following #defines to determine which icon to draw in the LCD
#define BLUE_SQUARE 1
#define HONEYDROP_SQUARE 2
#define PWRUP_SQUARE 3
#define GHOST_ICON 4
#define BUZZY_ICON 5
#define TRAP_LINE 6

When drawing the ghosts draw one of each color
*/    

void DrawMaze()
{

    for (int ii = 0 ; ii < MAZE_NUM_ROW ; ii++)
    {
        for (int jj = 0 ; jj < MAZE_NUM_COL ; jj++)
        {
            gDynaMaze[ii][jj] = gCnstMaze[ii][jj]; // setup dynamic maze
            int currVal = gCnstMaze[ii][jj];
            switch (currVal)
            {
                case BLUE_SQUARE:
                    DrawMazeWall(ii,jj);
                    break;
                case HONEYDROP_SQUARE:
                    guLCD.BLIT(ii*3, jj*3, 3, 3, &HoneyDropIcon[0][0]);
                    ++nd;
                    break;
                case PWRUP_SQUARE:
                    guLCD.BLIT(ii*3-2, jj*3-2, 9, 9, &PowerUpIcon[0][0]);
                    break;
                case GHOST_ICON: // draw different color ghosts
                    if(kk == 0) 
                        {
                        guLCD.BLIT(ii*3+6, jj*3-2, 9, 9, &VioletGhost[0][0][0]);
                        }
                    else if (kk == 1) {
                        guLCD.BLIT(ii*3, jj*3-2, 9, 9, &BlueGhost[0][0][0]);
                        }
                    else if (kk == 2) {
                        guLCD.BLIT(ii*3, jj*3-2, 9, 9, &PinkGhost[0][0][0]);                        }
                    else if (kk == 3) {
                        guLCD.BLIT(ii*3, jj*3-2, 9, 9, &GreenGhost[0][0][0]);
                        }
                        kk = (kk+1)%4;
                    break;
                case BUZZY_ICON:
                    gBuzzy.DrawInNewLocation(ii,jj); // draw Buzzy in starting position
                    break;
                case TRAP_LINE:
                    //guLCD.BLIT(ii*3, jj*3, 9, 9, &TrapLine[0][0]);
                    break;
                    
            } // end of switch
        }
        
    }
}
