#include "hangman.h"
#include <iostream>
using namespace std;

/*
Issues to fix:
- Guessing same incorrect letter twice counts twice as wrong (or leave as a punishment)
- Incorrect letters not being registed as incorrect after correct letters (fixed)
- Other than these, basically no functional errors, just stylistic changes left
*/

hangman game;
extern int inc;
int k = 0;
char letters_guessed[6] = {'-','-','-','-','-','-'};
char gs;
bool valid = false;
bool match = false;
bool ag = false;
string wrd = game.WordToGuess();
char * lg = letters_guessed;

bool CheckIfGuessed(char let) {
    bool guessed =  false;
    for (int i = 0;i < 6;++i) {
        if (letters_guessed[i] == let) {
            guessed = true;
            cout << "You already guessed " << let << ". Try another letter." << endl;
            for (int i = 0;i < 6;++i)
                cout << lg[i] << " ";
            cout << endl;
            return guessed;
        }
    }
    return guessed; // user has not guessed letter
}

bool CheckIfWon() {
    bool win[wrd.length()];
    for (int i = 0; i < wrd.length();++i)
        win[i] = game.bank[i] == game.getWordPtr()[i]; // should all be 1s if win condition is met
    
    bool w = win[0];
    for(int i = 1;i < wrd.length();++i)
        w = w && win[i]; // w should remain true if all of win is true;
    if (w == true) {
        cout << "YOU WIN!!!" << endl;
        return true;
    }
    else
    {
        w = false;
        return w;
    }
    
}

bool CheckIfLost() {
    if (letters_guessed[5] != '-') {
        cout << "You lost..." << endl;
        return true;
    }
    else
        return false;
}

void hangman_game() {
while (CheckIfWon() == false) {
    
    while (valid == false) {
        valid = game.valid_guess(); // keep checking if guess is valid
        if (valid == true) {
            gs = game.getGuess();
            ag = CheckIfGuessed(gs); // keep checking if already guessed
        }
        if (ag == false)
            break;
    }

    match = game.check_guess(gs); // check if guess is right or wrong

    if (match == false) {
        letters_guessed[k] = gs;
        ++k;
        game.SetupHangMan();
        valid = false; // reset valid
        cout << "Incorrect guesses: ";
        for (int i = 0;i < sizeof(letters_guessed);++i) {
            if (i < 5) 
                cout << lg[i] <<",";
            else
                cout << lg[i] << endl;    
        }
        cout << "Mystery word: ";
        game.PrintBank();
    }
    else if (match == true) {
        game.UpdateBank(gs); // insert letter in letter bank
        cout << "Mystery word: ";
        game.PrintBank(); // show new letter bank
        valid = false; // reset valid

        cout << "Incorrect guesses: ";
        for (int i = 0;i < sizeof(letters_guessed);++i) {
            if (i < 5) 
                cout << lg[i] <<",";
            else
                cout << lg[i] << endl;    
        }
    }

    if (CheckIfLost() == true)
        break;
}

}

int main() {
    game.stringToCharArray(wrd); // convert string to char array
    game.SetupHangMan();
    game.word_bank(); // make letter bank
    game.PrintBank(); // ^ all setup for game
    hangman_game(); //start game
    return 0;
}